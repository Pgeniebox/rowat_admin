let newArray = lib0.map(obj => {
    let newObj = { };
    newObj['a'] = obj.aqwal; 
 newObj['n'] = obj.name; 
    newObj['z'] = obj.r_zahbi; 
    newObj['r'] = obj.rotba; 
     newObj['s'] = obj.sheokh; 
    newObj['tb'] = obj.tabaqa;
        newObj['tl'] = obj.tlameez;
           newObj['d']  =  obj.death;
            newObj['b'] = obj.birth
    return newObj;
});
lib0= [{a:'أقوال',n:'إسم',z:'الذهبي',r:'رتبة',s:'شيوخ',tb:'طبقة',tl:'تلاميذ',d:'ت.وفاة',b:'ت.ميلاد'},newArray]





// Method 1: Using for...in loop
let start1 = performance.now();

let objsWithYuiKey1 = lib0.filter(obj => {
    
 
   return Object.keys(obj)[1].includes('الألباني');
});

let end1 = performance.now();
console.log("Method 1 Execution Time: " + (end1 - start1) + " milliseconds");


let objsWithYuiKey1 = lib0.filter(obj => {
    return Object.keys(obj)[1].includes('الألباني');
 }).entries().next().value[1].bk;

lib1.map(abj=>{
    abj.bk = {};
       

lib0 = lib0.map(obj=>{
    let nbj = {};
    let hbj = {};
    nbj['bid'] = obj[1].bid;
    nbj['d'] = obj[1].d;
    abj.bk[obj[0]] = nbj;
    return obj[1].p;   
});
});